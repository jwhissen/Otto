/*
Core definitions and functions for the program

*/

#ifndef HEADER_H
#define HEADER_H
#include "Display.h"
#include "JungleTimers.h"


const int CAMPS = 14;			// based off the number of camps in game

extern bool runProg;			// used to safely join threads back in
extern camp myCamps[CAMPS];		// These need to be initialized 

void timen(camp*);				// timer controller thread
#endif
/*
League of Legends Jungle Timer software with large buttons for easier touch input

Jeffrey Whissen
Created: 4/10/2014
Last Modified: 4/13/2014

Todo:
	Screen flash due to blitting needs to be fixed
	Pictures need to become the buttons
	Time display larger
	Organize red and blue sides
	Game restart timer
	Buttons to advance or reduce timer in smaller increments
	Window should not resize or be dynamic with buttons/pics

Potential future:
	Twisted Treeline camps

*/

#include "Header.h"

bool runProg = true;
camp myCamps[CAMPS];


//Main
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,LPSTR lpCmdLine, int nCmdShow){
	int msg,a;

	myCamps[0] = camp(300, "Blue", true, 115);
	myCamps[1] = camp(300, "Blue", false, 115);
	myCamps[2] = camp(300, "Red", true, 115);
	myCamps[3] = camp(300, "Red", false, 115);
	myCamps[4] = camp(50, "Wight", true, 125);
	myCamps[5] = camp(50, "Wight", false, 125);
	myCamps[6] = camp(50, "Golems", true, 125);
	myCamps[7] = camp(50, "Golems", false, 125);
	myCamps[8] = camp(50, "Wolves", true, 125);
	myCamps[9] = camp(50, "Wolves", false, 125);
	myCamps[10] = camp(50, "Wraiths", true, 125);
	myCamps[11] = camp(50, "Wraiths", false, 125);
	myCamps[12] = camp(360, "Dragon", false, 300);
	myCamps[13] = camp(420, "Baron", false, 900);

	std::thread times(timen, myCamps);

	a = display(hInstance, hPrevInstance, lpCmdLine, nCmdShow);

	msg = updateS();

	runProg = false;
	times.join();

	return msg;
}

// thread handle to 
void timen(camp* campIn){
	int curCamp;

	while (runProg){
		for(curCamp = CAMPS; curCamp >= 0; curCamp--)
			campIn[curCamp].update();
		Sleep(500);
	}
}

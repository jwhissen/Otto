/*
This section defines the functions that are used to control the individual camp detaiuls and timers

*/

#include "JungleTimers.h"


// Std constructor, should not be used
camp::camp(){
	respawn = 0;
	current = 0;
	name = "Unknown";
	blue = true;
	outCurString = "00:00";
	//outCurrent = outCurString.c_str();
	//outName = name.c_str();
	start = std::clock();
}


camp::~camp(){

}

// should always use this constructor
camp::camp(int a, std::string b, bool c, int initial){
	respawn = a;
	current = a - initial;
	name = b;
	blue = c;
	//outCurrent = "0:00";
	start = std::clock() - current*CLOCKS_PER_SEC;
}

// updates the time
int camp::update(){
	std::ostringstream a;
	std::string c;

	current = respawn - ((clock() - start) / CLOCKS_PER_SEC);

	if (current < 0)
		current = 0;

	if (current % 60 < 10)
		a << floor(current / 60) << ":0" << current % 60;
	else
		a << floor(current / 60) << ":" << current % 60;
	outCurString = a.str();
	
	return 0;
}

// resets camp timer
void camp::startTimer(){
	start = std::clock();
}

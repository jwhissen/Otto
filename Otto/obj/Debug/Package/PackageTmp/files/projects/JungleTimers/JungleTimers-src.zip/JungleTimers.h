/*
Header file for League of Legends Jungle Timer system

Jeffrey Whissen
*/


#ifndef JUNGLETIMERS_H
#define JUNGLETIMERS_H


#include <iostream>
#include <thread>
#include <cstring>
#include <ctime>
#include <sstream>
#include <windows.h>


// Defines a individual camp in the game.  These camps have their times defined by the game and will be loaded from an ini file
class camp {
	public:
		camp();								// Std constructor, should not be used
		~camp();
		camp(int,std::string,bool,int);		// should always use this initializer

		int update();						// updates the time
		void startTimer();					// resets camp timer
		
		std::string name;					// camp name
		std::string outCurString;			// respawn time as ##:## string
		bool blue;							// blue side or red

	private:
		int respawn;						// time in seconds
		int current;						// time in seconds
		std::clock_t start;					// time in clocks
};



#endif
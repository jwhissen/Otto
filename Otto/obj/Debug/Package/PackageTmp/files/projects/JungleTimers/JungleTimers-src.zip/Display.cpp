/*  
Handles display to screen.  

*/


#include "Display.h"


HDC hdcMem;
HWND hWnd;
std::string timer[CAMPS];


int display(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow){
	WNDCLASSEX wcex;			//Window class information

	//Defining Window class information
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_APPLICATION));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = windowClass;
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_APPLICATION));

	//Register Window or error
	if (!RegisterClassEx(&wcex)){
		MessageBox(NULL, "Unable to Register Window", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 1;
	}

	//Create Window	
	hWnd = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		windowClass,
		windowName,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		725,
		450,
		HWND_DESKTOP,
		NULL,
		hInstance,
		NULL);


	if (!hWnd){
		MessageBox(NULL, "Unable to Create Window", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 1;
	}

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);


	return 0;
}


int updateS(){
	MSG msg;

	std::thread updateScreen(screen);
	
	//Message handling
	while (GetMessage(&msg, NULL, 0, 0) > 0){
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	runProg = false;
	updateScreen.join();
	return msg.wParam;
}
	


void screen(){
	int curCamp;

	while (runProg){
		//LoadPic();
		for (curCamp = CAMPS - 1; curCamp >= 0; curCamp--){
			timer[curCamp] = myCamps[curCamp].outCurString;
		}
		
		InvalidateRect(hWnd, NULL, true);  // tell the window it needs to redraw (sends a WM_PAINT message
		Sleep(500);
	}


}

//Window procedure
LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){
	PAINTSTRUCT ps;
	HDC hdc;
	int curCamp;
	int buttonX = 100;
	int buttonY = 25;
	int textX = 120;
	int textY = 5;
	int picX = 0;
	int picY = 0;

	switch (msg){
	case WM_COMMAND:
		myCamps[wParam-1].startTimer();

	case WM_CREATE:
		for (curCamp = CAMPS - 1; curCamp >= 0; curCamp--){
			CreateWindow(
				TEXT("BUTTON"),
				myCamps[curCamp].name.c_str(),
				WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
				buttonX, buttonY, 75, 75,
				hWnd, (HMENU)(curCamp+1), NULL, NULL
				);
			buttonY = buttonY + 100;
			if (curCamp % 4 == 0){
				buttonX = buttonX + 175;
				buttonY = 25;
			}
		}
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		for (curCamp = CAMPS - 1; curCamp >= 0; curCamp--){
			picLoad(curCamp);
			StretchBlt(hdc, picX, picY, 100, 100, hdcMem, 10, 10, 100, 100, SRCCOPY);
			picY = picY + 100;
			if (curCamp % 4 == 0){
				picX = picX + 175;
				picY = 0;
			}
		}
		for (curCamp = CAMPS - 1; curCamp >= 0; curCamp--){
			if (!timer[curCamp].empty())
				TextOut(hdc, textX, textY, (timer[curCamp].c_str()), timer[curCamp].length());
			textY = textY + 100;
			if (curCamp % 4 == 0){
				textX = textX + 175;
				textY = 5;
			}
		}
		EndPaint(hWnd, &ps);
		break;
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}

	return 0;
}




// loads pic to be blitted
void picLoad(int curPic){
	HBITMAP bmp = NULL;
	HBITMAP oldBmp = NULL;
	std::string picName;	

	picName = "images/" + myCamps[curPic].name + ".bmp";
	bmp = (HBITMAP)LoadImage(NULL, picName.c_str(), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	if (!bmp)			// Unable to load;
		return;	

	hdcMem = CreateCompatibleDC(NULL);
	oldBmp = (HBITMAP)SelectObject(hdcMem, bmp);
}

/*
Header file for handling display to screen.

*/

#ifndef DISPLAY_H
#define DISPLAY_H


#include "Header.h"
#include "JungleTimers.h"


const char windowClass[] = "jungleTimerDisplay";
const char windowName[] = "Jungle Timers for League of Legends";



int display(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow);
int updateS();

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

void picLoad(int);
void screen();


#endif